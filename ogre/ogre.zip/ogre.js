function removeShorts() {
  // Cast a wide net — grab any element that could be a shelf/section
  document.querySelectorAll([
    "ytd-rich-shelf-renderer",
    "ytd-shelf-renderer", 
    "ytd-item-section-renderer",
    "ytd-reel-shelf-renderer"
  ].join(",")).forEach(shelf => {
    const text = shelf.textContent;
    if (text.includes("Shorts")) {
      shelf.remove();
    }
  });

  document.querySelectorAll([
    "ytm-shorts-lockup-view-model",
    "ytd-reel-item-renderer",
    "a[href*='/shorts/']"
  ].join(",")).forEach(el => {
    el.closest("ytd-rich-item-renderer, ytd-item-renderer, li") ?.remove() || el.remove();
  });
}

function removeHomeAndShortsOptions() {
  document.querySelectorAll("ytd-guide-section-renderer, ytd-mini-guide-entry-renderer")
    .forEach(element => {
      const text = element.textContent;
      const ariaLabel = element.getAttribute("aria-label") 
                     || element.querySelector("[aria-label]")?.getAttribute("aria-label");
      
      if (text.includes("Home") || ariaLabel === "Home") {
        element.remove();
      }
    });
}

function start_at_subscriptions(){
    if (window.location.pathname === "/") {
        window.location.replace("https://www.youtube.com/feed/subscriptions");
    }
}

function remove_recommendations(){
    document.querySelectorAll("ytd-watch-flexy"
    ).forEach(element => {
        const rec = element.querySelector("#secondary")
        if(rec){
            rec.remove()
        }
    })
}

function main(){
    removeShorts();
    removeHomeAndShortsOptions();
    start_at_subscriptions();
    remove_recommendations();
}


const observer = new MutationObserver(main);
observer.observe(document.body, { childList: true, subtree: true });